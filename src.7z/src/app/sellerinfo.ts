export class SellerInfo{
   
   sname:string;
   oid:string;
    title:String;
    desc:String;
}