export class SellerLogin{
    name: string;
    email:string;
    uname: string;
    pass: string;
}