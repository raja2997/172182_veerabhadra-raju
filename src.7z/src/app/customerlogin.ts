export class CustomerLogin {
    
    uname: string;
    pass: string;
}
