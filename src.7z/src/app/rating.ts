export class Rating{
   
    sname:string;
    
     title:String;
    rating:string;
    bname:string;
 }