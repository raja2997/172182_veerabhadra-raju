export class Customer {
    
    name: string;
    email:string;
    uname: string;
    pass: string;
   
}
