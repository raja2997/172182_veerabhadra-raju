import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private baseUrl = 'http://localhost:8887';
  currentuser:any;
  currentseller:any;
  constructor(private http: HttpClient) { }

  getCustomer(id: number): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createCustomer(customer: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, customer);
  }

  createSellerItem(seller: Object): Observable<Object> {
    console.log(seller)
    return this.http.post(`${this.baseUrl}` + `/sellerinfo`, seller);
  }
  createSeller(customer: Object): Observable<Object> {
    console.log(customer)
    return this.http.post(`${this.baseUrl}` + `/sellerdata/addseller`, customer);
  }
 createBuyerInfo(rating: Object): Observable<Object> {
   console.log("in service")
   console.log(rating)
   
     this.http.post(`http://localhost:3333/api/raja`,rating).subscribe((res)=>{

     });

     return 
  }
 
  updateCustomer(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteCustomer(id: String): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getCustomersList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/seller`);
  }
  getBuyerList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/info`);
  }
  getCustomersByAge(customer:Object): Observable<any> {
    console.log(customer)
    console.log(`${this.baseUrl}`+`/valid`)
    this.http.post(`${this.baseUrl}`+`/valid`,customer).subscribe((response)=>{
      this.currentuser=response;
    })

    return this.currentuser;
  }
  getSellerValid(customer:Object): Observable<any> {
    console.log(customer)
    console.log(`${this.baseUrl}`+`/sellerdata/validateseller`)
     this.http.post(`${this.baseUrl}`+`/sellerdata/validateseller`,customer).subscribe((response)=>{
      this.currentseller=response;
    })
    
    return this.currentseller;
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.baseUrl}` + `/delete`, { responseType: 'text' });
  }

}
