import React,{Component} from 'react'

class Message extends Component{
    constructor(){
        super()
        this.state={
            message:'Welcome King',
            count:0
        }
    }
    changeMessage(){
        this.setState({
            message:'Thank you for your great ruling',
            count:this.state.count + 1

        })
    }
    render(){
        return(
            <div>
            <h1>{this.state.message}</h1>
          
            <button onClick={() => this.changeMessage()}>Rule Us</button>
            
            <b>Thanks for Voting {this.state.count}</b>
            </div>
        ) 
    }
}
export default Message